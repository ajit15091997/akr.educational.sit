const express = require("express");
const multer = require("multer");
const cors = require("cors");
const ffmpeg = require("fluent-ffmpeg");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(cors());
app.use(express.json());

const upload = multer({ dest: "uploads/" });

app.post(
  "/api/create-video",
  upload.fields([
    { name: "image", maxCount: 1 },
    { name: "voiceAudio", maxCount: 1 },
    { name: "bgAudio", maxCount: 1 },
  ]),
  (req, res) => {
    const imageFile = req.files["image"]?.[0];
    const voiceFile = req.files["voiceAudio"]?.[0];
    const bgFile = req.files["bgAudio"]?.[0];
    const {
      voiceVolume = 1,
      bgVolume = 0.4,
      watermarkText = "Created by Ajit",
    } = req.body;

    if (!imageFile || !voiceFile) {
      return res.status(400).json({ error: "Image and voice audio required" });
    }

    if (!fs.existsSync(path.join(__dirname, "outputs"))) {
      fs.mkdirSync(path.join(__dirname, "outputs"));
    }

    const outputFileName = `output_${Date.now()}.mp4`;
    const outputPath = path.join(__dirname, "outputs", outputFileName);

    ffmpeg.ffprobe(voiceFile.path, (err, metadata) => {
      if (err) return res.status(500).json({ error: "ffprobe error" });
      const duration = metadata.format.duration;

      let command = ffmpeg();

      command.input(imageFile.path).loop(duration).inputOptions(["-framerate 1"]);
      command.input(voiceFile.path);
      if (bgFile) command.input(bgFile.path);

      command
        .complexFilter([
          {
            filter: "scale",
            options: { w: 1280, h: 720, force_original_aspect_ratio: "decrease" },
            inputs: "0:v",
            outputs: "scaled",
          },
          {
            filter: "pad",
            options: { w: 1280, h: 720, x: "(ow-iw)/2", y: "(oh-ih)/2", color: "black" },
            inputs: "scaled",
            outputs: "padded",
          },
          {
            filter: "drawtext",
            options: {
              text: watermarkText,
              fontcolor: "white@0.7",
              fontsize: 24,
              x: "(w-text_w)-10",
              y: "(h-text_h)-10",
              shadowcolor: "black",
              shadowx: 2,
              shadowy: 2,
            },
            inputs: "padded",
            outputs: "watermarked",
          },
        ])
        .on("error", (err) => {
          console.error("FFmpeg error:", err);
          res.status(500).json({ error: "Video creation failed" });
        })
        .on("end", () => {
          // Cleanup uploads
          fs.unlinkSync(imageFile.path);
          fs.unlinkSync(voiceFile.path);
          if (bgFile) fs.unlinkSync(bgFile.path);

          res.json({ videoUrl: `/outputs/${outputFileName}` });
        })
        .save(outputPath);
    });
  }
);

app.use("/outputs", express.static(path.join(__dirname, "outputs")));

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});