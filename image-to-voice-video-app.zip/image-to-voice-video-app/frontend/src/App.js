import React from "react";
import VideoCreator from "./components/VideoCreator";

function App() {
  return (
    <div>
      <VideoCreator />
    </div>
  );
}

export default App;