import React, { useState } from "react";

export default function VideoCreator() {
  const [image, setImage] = useState(null);
  const [voice, setVoice] = useState(null);
  const [bgAudio, setBgAudio] = useState(null);
  const [voiceVolume, setVoiceVolume] = useState(1);
  const [bgVolume, setBgVolume] = useState(0.4);
  const [watermarkText, setWatermarkText] = useState("Created by Ajit");
  const [videoUrl, setVideoUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCreateVideo = async () => {
    if (!image || !voice) {
      alert("Please upload image and voice audio!");
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append("image", image);
    formData.append("voiceAudio", voice);
    if (bgAudio) formData.append("bgAudio", bgAudio);
    formData.append("voiceVolume", voiceVolume);
    formData.append("bgVolume", bgVolume);
    formData.append("watermarkText", watermarkText);

    try {
      const res = await fetch("http://localhost:5000/api/create-video", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      setVideoUrl("http://localhost:5000" + data.videoUrl);
    } catch (err) {
      alert("Error creating video");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        maxWidth: 600,
        margin: "auto",
        padding: 20,
        background: "#6b46c1",
        color: "white",
        borderRadius: 12,
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h1 style={{ textAlign: "center" }}>🎥 Image to Voice-Over Video</h1>

      <input type="file" accept="image/*" onChange={(e) => setImage(e.target.files[0])} />
      <br />
      <input type="file" accept="audio/*" onChange={(e) => setVoice(e.target.files[0])} />
      <br />
      <input type="file" accept="audio/*" onChange={(e) => setBgAudio(e.target.files[0])} />
      <br />

      <label>
        Voice Volume: {voiceVolume}
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={voiceVolume}
          onChange={(e) => setVoiceVolume(e.target.value)}
        />
      </label>
      <br />
      <label>
        Background Volume: {bgVolume}
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={bgVolume}
          onChange={(e) => setBgVolume(e.target.value)}
        />
      </label>
      <br />
      <input
        type="text"
        placeholder="Watermark text"
        value={watermarkText}
        onChange={(e) => setWatermarkText(e.target.value)}
        style={{ width: "100%", padding: 8, borderRadius: 4, marginBottom: 10 }}
      />
      <br />

      <button
        onClick={handleCreateVideo}
        disabled={loading}
        style={{
          padding: "10px 20px",
          borderRadius: 8,
          background: "#f687b3",
          color: "#333",
          fontWeight: "bold",
          cursor: "pointer",
        }}
      >
        {loading ? "Processing..." : "Create Video"}
      </button>

      {videoUrl && (
        <div style={{ marginTop: 20 }}>
          <h3>🎬 Video Ready:</h3>
          <video src={videoUrl} controls width="100%" />
          <a href={videoUrl} download style={{ display: "block", marginTop: 10, color: "#ffd700" }}>
            ⬇️ Download Video
          </a>
        </div>
      )}
    </div>
  );
}